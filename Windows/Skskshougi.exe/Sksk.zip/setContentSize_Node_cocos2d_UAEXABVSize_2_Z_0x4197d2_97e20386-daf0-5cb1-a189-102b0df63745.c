// ============================================================
// 函数名称: ?setContentSize@Node@cocos2d@@UAEXABVSize@2@@Z
// 虚拟地址: 0x4197d2
// WARP GUID: 97e20386-daf0-5cb1-a189-102b0df63745
// 源二进制: E:/torrent/Cursor/SkskShogi-1.022-win/SkskShogi.exe.bndb
// ------------------------------------------------------------
// [交叉引用字符串]: 无
// [外部 API 调用]: 无
// [内部子函数调用]: 无
// [被调用的父级函数]: 无
// ============================================================

void __thiscall?setContentSize@Node@cocos2d@@UAEXABVSize@2@@Z(cocos2d::Node* this, class cocos2d::Size const& arg2)
{
    // 第一条实际指令: return cocos2d::Node::setContentSize(this, arg2) __tailcall
    return cocos2d::Node::setContentSize(this, arg2) __tailcall
}
