// ============================================================
// 函数名称: __crtSetUnhandledExceptionFilter
// 虚拟地址: 0x41a3d2
// WARP GUID: 97e20386-daf0-5cb1-a189-102b0df63745
// 源二进制: E:/torrent/Cursor/SkskShogi-1.022-win/SkskShogi.exe.bndb
// ------------------------------------------------------------
// [交叉引用字符串]: 无
// [外部 API 调用]: 无
// [内部子函数调用]: 无
// [被调用的父级函数]: ___CxxSetUnhandledExceptionFilter
// ============================================================

int32_t__crtSetUnhandledExceptionFilter()
{
    // 第一条实际指令: return __crtSetUnhandledExceptionFilter() __tailcall
    return __crtSetUnhandledExceptionFilter() __tailcall
}
